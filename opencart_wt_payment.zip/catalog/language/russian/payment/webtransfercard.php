<?php
// Text
$_['text_title'] = 'WebTransferCard';
$_['sub_text_info'] = '';
$_['sub_text_info_phone'] = 'cewc: ';
$_['total_mes'] = 'Итого к оплате: ';
?>